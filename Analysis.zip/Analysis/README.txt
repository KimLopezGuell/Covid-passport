For the moment, the "Analysis" folder only contains negative binomial regression models on Denmark, Germany and France cases data.
As the models were nonsensical for time intervals with several monotony and convexity changes, each Covid Passport intervention change in intensity has been isolated and is modelled in its local time interval independently of the others. The time interval has been chosen such that there is no monotony change in either side of the intervention time point. 

Data has been smoothed taking a 7-day average, and "NA" values have been added for negative incorrect data points. A lag of 5 days has been taken.

The following plots and files can be found:

"Some_countries_cases" : Plot for some of the regions, to see the need to take each NPI change on its own. In red, changes in Passport Covid NPI (dates to be found in "NPI_data" doc). In blue, other NPIs (unvaccinated restrictions or circuit breakers), if applicable.

For each country, CP# means the # change of the Covid Passport intervention.
In each COUNTRY/cases/CP* folder:
- "COUNTRY images_CP#" : Plot of the cases for the selected time interval of the intervention change + Fitted values at each side of the intervention/lag for the BNreg model + Predicted values without the intervention.
- "glm_output.txt" : Model summary, coefficients and exp(coefficients), Durbin-Watson test of the residuals which show in general the need to take autocorrelation into account.
- "Model_NPreg_residuals_CP*" : Residual plots for the models.
